#ifndef HAVE_CRC_H
#define HAVE_CRC_H

#include "base.h"

uint16_t crc16(uint16_t *data, int len);

#endif /* HAVE_CRC_H */
