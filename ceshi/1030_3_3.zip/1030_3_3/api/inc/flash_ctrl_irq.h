#ifndef __FLASH_CTRL_IRQ_H__
#define __FLASH_CTRL_IRQ_H__

#define FLASH_CTRL_NUM_IRQS 0

#endif
