#ifndef __IOMUX_CTRL_IRQ_H__
#define __IOMUX_CTRL_IRQ_H__

#define IOMUX_CTRL_NUM_IRQS 0

#endif
