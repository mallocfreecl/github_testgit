#ifndef CCTIMER_H_
#define CCTIMER_H_
#include "api.h"
#include "commons.h"

void mcu_diag_out_low(void);
void mcu_diag_out_high(void);
void mcu_diag_out_toggle(void);

#endif /* CCTIMER_H_ */
