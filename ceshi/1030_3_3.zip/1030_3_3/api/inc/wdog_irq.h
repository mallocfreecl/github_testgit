#ifndef __WDOG_IRQ_H__
#define __WDOG_IRQ_H__

#define WDOG_NUM_IRQS 1

typedef enum
{
  WDOG_IRQ_EVT_WINDOW = 0
} wdog_irq_t;

#endif
