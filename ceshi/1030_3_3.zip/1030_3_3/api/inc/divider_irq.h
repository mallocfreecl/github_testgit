#ifndef __DIVIDER_IRQ_H__
#define __DIVIDER_IRQ_H__

#define DIVIDER_NUM_IRQS 1

typedef enum
{
  DIVIDER_IRQ_EVT_DIV_BY_ZERO = 0
} divider_irq_t;

#endif
