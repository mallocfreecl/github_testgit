#ifndef __H430_MUL_IRQ_H__
#define __H430_MUL_IRQ_H__

#define H430_MUL_NUM_IRQS 0

#endif
