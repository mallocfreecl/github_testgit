function blkStruct = slblocks

Browser(1).Library = 'lib1';
Browser(1).Name    = 'lib1';

blkStruct.Browser = Browser;